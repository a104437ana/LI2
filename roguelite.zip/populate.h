#include "state.h"

void draw_map(STATE *st);
void draw_player(STATE *st);
void draw_info(STATE *st);
void draw_monsterRato(STATE *st);
void draw_monsterDog(STATE *st);
void draw_monsterBat(STATE *st);
void draw_arma_faca (STATE *st);
void draw_arma_pistola (STATE *st);
void draw_pocao (STATE *st);
void draw_bomba (STATE *st);