#include "state.h"

void iluminacao(STATE *st);