#include "state.h"

void do_movement_action(STATE *st, int dx, int dy);
void movimento_monstros (STATE *st, int i);