#include "state.h"

void update(STATE *st);