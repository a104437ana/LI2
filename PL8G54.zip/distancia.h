#include "state.h"

void reset_dist(STATE *st);
void calc_dist(int R, int C, int value, STATE *st);